/* 클래스 - 모든 게임 오브젝트 아이템 */
GAME_ITEM_ID = 1;


/*
    arrangeType
    아이템 배치 타입:
        N : 배치 안됨.
        PB : 플레이어 가방
        PE : 플레이어 착용
        G : 땅바닥

    roomNo : 땅바닥인 경우 방 번호
*/
function GameItem(itemName, type, effectPoint, arrangeType = "N", roomId=0) {
    GAME_ITEM_ID++; //1증가 후 부여
    this.id = GAME_ITEM_ID;
    this.itemName = itemName;
    /* 타입 */
    /*
    체력물약
    
    .. todo 추가예정
    */
    this.type = type;       // 타입 :
    this.effectPoint = effectPoint; // 영향 포인트. ex. 물약이면 회복량
    this.arrangeType = arrangeType;
    this.roomId = roomId;
}