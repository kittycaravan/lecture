/* 공통 함수만 여기에 */
function dice(n){
    return Math.floor(Math.random()*n+1);
}
function log(s){
    console.log(s);
}
function getRandomArray(ar){
    log(ar);
    log(ar.length);
    let l = ar.length;
    return ar[dice(l)-1];
}
