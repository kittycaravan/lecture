/* 보상 획득 처리 */
function rewardGetReward(dieMonster) {
    // 보상 - 경험치 처리
    elf.exp = elf.exp + dieMonster.exp;

    // 레벨업 체크
    lvCheckLevelup();

    // - 전투 종료 후 경험치 획득 메세지 출력 ex. 불쌍한 토끼, 엠피스에게 경험치 100 을 주고 죽었습니다.
    tv("불쌍한 " + dieMonster.name + ", " + elf.name + "에게 경험치 " + dieMonster.exp + "을 주고 죽었습니다.\n");

    // 보상 - 돈
    elf.money = elf.money + dieMonster.money;
    tv(dieMonster.money + "원을 얻었습니다.\n");

    // 보상 - 아이템 드랍
    //todo
    //전튜력 bp 를 기준으로 랜덤 드랍 처리
    //임시로 7번몹을 잡았을 때만 드랍
    log(`==== dieMonster.id : ${dieMonster.id}`);
    if(dieMonster.id==2){
        dropItemByBp(dieMonster.bp);
    }
    //todo
    //드랍된 아이템 다시한번 보이게 처리
    displayCurrentRoomGroundItemsInfo();   //방에 있는 바닥 아이템들 출력

}

/* 전튜력 bp 를 기준으로 랜덤 드랍 처리 */
function dropItemByBp(bp){
    //todo
    //임시. 일단은 무조건 id 2 아이템 고정 드랍
    //향후 bp 값 베이스로 랜덤 확률 드랍 처리. (bp 가 높을 수록 아이템 퀄리티가 좋게 나올 가능성 높게 처리)
    
    //todo

    //todo
    //현재 플레이어 위치에 드랍 처리
    groundItems.push(new GameItem(2,"G",currentRoomId));

}