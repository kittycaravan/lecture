/* 공통 함수만 여기에 */
function dice(n){
    return Math.floor(Math.random()*n+1);
}

