package com.peisia.jsp.q004;

public class Cat {
	
	public String name = "고양이";
	
	public String x() {
		System.out.println("== 고양이 로그");
		return "키티";
	}
}
