package com.peisia.q23;

public class Bean {
	private String name;
	private int number;
	
	//name 변수의 겟터 정의하기
	public String getName() {
		return name;
	}
	//name 변수의 세터 정의하기
	public void setName(String name) {
		this.name = name;
	}
	
	//number 변수의 게터 정의하기
	public int getNumber() {
		return number;
	}
	//number 변수의 세터 정의하기
	public void setNumber(int number) {
		this.number = number;
	}
	
	

}
