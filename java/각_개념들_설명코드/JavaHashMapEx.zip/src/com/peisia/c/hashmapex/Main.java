package com.peisia.c.hashmapex;

import java.util.HashMap;

public class Main {

	public static void main(String[] args) {
		// 키 - 밸류
		//request.setAttribute("a",1);
		//HashMap<String,Long> x = new HashMap<String,Long>();
		HashMap<String,Integer> x = new HashMap<>();	// 줄여쓰기 가능.
		
		//.값 넣기
		x.put("a", 1);	// 첫번째 매개변수에 키, 두번째에 값.
		x.put("b", 2);	// .. 계속..
		
		//.값 빼기
		int c = x.get("a");	// 매개변수에 키 값 넣으면 값이 리턴됨.
		int d = x.get("b");
		
		int sum = c+d;
		System.out.println(sum);

		//.값 지우기
		x.remove("a");
		
		System.out.println(x.size());	// 사이즈 함수 : 갯수 리턴
		
		//.해쉬맵 내 키-밸 데이터를 다 비우기
		x.clear();
		
		System.out.println(x.size());
		
		int f = x.get("a");
		System.out.println(f);
	}

}
