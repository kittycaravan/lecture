package com.peisia.cardcat;

import com.peisia.game.card.cardcat.CardCat;

public class Main {

	public static void main(String[] args) {
		CardCat cc = new CardCat();
		cc.gameRun();
	}

}
