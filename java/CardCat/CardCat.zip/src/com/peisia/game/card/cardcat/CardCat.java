package com.peisia.game.card.cardcat;

import java.util.HashMap;
import java.util.Scanner;

import com.peisia.util.game.Dice;

public class CardCat {
	private static final int USER_START_GOLD = 10;
	private static final int COM_START_GOLD = 10;
	private static final String MESSAGE_ONEGAME_WIN = "이겼다!!!";
	private static final String MESSAGE_ONEGAME_DRAW = "비겼다..";
	private static final String MESSAGE_ONEGAME_LOSE = "졌다....";
	private static final String MESSAGE_FINAL_WIN = "승리!";
	private static final String MESSAGE_FINAL_LOSE = "패배!";
	private int gameState = 0;
	private int userGold = USER_START_GOLD;
	private int comGold = COM_START_GOLD;
	private String lastResult;
	private HashMap<String,Object> gameData = new HashMap<>();
	
	
	public HashMap<String,Object> getGameData() {
		gameData.put("userGold",userGold);
		gameData.put("comGold",comGold);
		gameData.put("gameState",gameState);
		gameData.put("lastResult",lastResult);
		return gameData;
	}
	
	public void gameRun() {
		Scanner sc=new Scanner(System.in);
		loop:
		while(true) {
			System.out.println("1.패돌려, 2.상태확인, 3.끝");
			switch(sc.nextInt()) {
			case 1:
				oneGameRun();
				break;
			case 2:
				getGameData();
				System.out.println(gameData.get("userGold"));
				System.out.println(gameData.get("comGold"));
				System.out.println(gameData.get("gameState"));
				break;
			case 3:
				sc.close();
				break loop;
			default:
				System.out.println("명령x");
				break;
			}
		}
	}
	
	public void oneGameRun() {
		Card[] cards = Card.values();
		Card cardUser = cards[Dice.between(0, 12)];
		Card cardCom = cards[Dice.between(0, 12)];
		System.out.println("나:"+cardUser);
		System.out.println("컴터:"+cardCom);
		gameState = victoryCheck(cardUser,cardCom);
	}
	
	public int victoryCheck(Card cardUser, Card cardCom) {
		if(cardUser.ordinal() > cardCom.ordinal()) {
			System.out.println(MESSAGE_ONEGAME_WIN);
			userGold++;
			comGold--;
			if(finalVictoryCheck()) {
				System.out.println(MESSAGE_FINAL_WIN);
				return 2;
			}
			return 1;
		} else if(cardUser.ordinal() == cardCom.ordinal()) {	//enum 숫
			System.out.println(MESSAGE_ONEGAME_DRAW);
			return 0;
		} else {
			System.out.println(MESSAGE_ONEGAME_LOSE);
			userGold--;
			comGold++;
			if(finalLoseCheck()) {
				System.out.println(MESSAGE_FINAL_LOSE);
				return -2;
			}
			return -1;
		}
	}
	
	public boolean finalVictoryCheck() {
		if(comGold > 0) {
			return false; 
		}else {
			return true;
		}
	}
	public boolean finalLoseCheck() {
		if(userGold > 0) {
			return false; 
		}else {
			return true;
		}
	}

}