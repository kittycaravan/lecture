package com.peisia.kiosk.catcafe.product;

public class Drink extends Product{

	public Drink(String xx, int yy) {
		super(xx, yy);
	}

}
