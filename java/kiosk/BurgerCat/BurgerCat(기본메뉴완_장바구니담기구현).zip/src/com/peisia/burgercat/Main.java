package com.peisia.burgercat;

public class Main {
	public static void main(String[] args) {
		Kiosk kiosk = new Kiosk();
		kiosk.run();
	}
}
