package com.peisia.burgercat;

public class PetFood extends Food{

}
