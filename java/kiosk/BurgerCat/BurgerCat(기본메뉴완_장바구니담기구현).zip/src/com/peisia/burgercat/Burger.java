package com.peisia.burgercat;

public class Burger extends Food{

}
