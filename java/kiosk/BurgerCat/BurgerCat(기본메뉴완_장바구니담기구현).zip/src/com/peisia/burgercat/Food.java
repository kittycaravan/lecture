package com.peisia.burgercat;

public class Food extends Goods{
	public String expiryDate;
}
