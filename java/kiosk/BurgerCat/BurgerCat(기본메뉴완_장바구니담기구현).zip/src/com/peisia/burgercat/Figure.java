package com.peisia.burgercat;

public class Figure extends Goods{

}
