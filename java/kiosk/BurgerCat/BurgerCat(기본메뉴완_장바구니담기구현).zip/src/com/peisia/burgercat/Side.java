package com.peisia.burgercat;

public class Side extends Food{

}
