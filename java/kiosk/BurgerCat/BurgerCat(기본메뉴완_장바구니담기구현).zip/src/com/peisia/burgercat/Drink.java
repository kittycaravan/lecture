package com.peisia.burgercat;

public class Drink extends Food{

}
