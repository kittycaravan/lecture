package com.peisia.burgercat;

import java.util.ArrayList;

public class ProcDessert {
	public void run(ArrayList<String> basket) {

		loop:
		while(true) {
			Command cmd = new Command(); 
			String c = cmd.getCommand("명령을 입력해주세요."
					+"[1:팝핑캔디선데,2:선데,3:컵아이스크림"
					+",c:취소,b:뒤로] :");
			
			switch(c) {
			case "1":
				System.out.println("팝핑캔디선데");
				basket.add("팝핑캔디선데");
				break;
			case "2":
				System.out.println("선데 선택함");
				basket.add("선데");
				break;
			case "3":
				System.out.println("컵아이스크림 선택함");
				basket.add("컵아이스크림");
				break;
			case "c":
				System.out.println("취소");
				break loop;
			case "b":
				System.out.println("뒤로");
				break loop;
			}
		}
	}
}
