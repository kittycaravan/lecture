package com.peisia.burgercat;

public class Dessert extends Food{

}
