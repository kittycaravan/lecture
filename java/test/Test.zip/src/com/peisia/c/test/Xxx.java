package com.peisia.c.test;

import java.util.Scanner;

import com.peisia.c.util.So;

public class Xxx {	//접근제한자 public . 클래스임을 표시하는 키워드 class. 클래스이름인 Xxx (첫 대문자 주의. 해당 파일이름도 Xxx.java 로 똑같아야 함 주의)
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		So.p("고르시오 [5=배열] :");
		int n = sc.nextInt();
		switch(n) {
		case 1:
			break;
		case 5:
			StudyArray sa = new StudyArray();
			sa.run();
			break;
		}
	}
}