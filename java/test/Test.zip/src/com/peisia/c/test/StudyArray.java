package com.peisia.c.test;

import com.peisia.c.util.So;

//줄맞춤 단축키: ctrl + shift + f
public class StudyArray {
	void run() {
//		정수형 배열 선언:
//		int[] numbers;
//			문자열 배열 선언:
		String[] names;
//			실수형 배열 선언:
		double[] values;
//			논리형 배열 선언:
		boolean[] flags;
//			객체 배열 선언:
		Cat[] objects;
//			2차원 정수형 배열 선언:
		int[][] matrix;
//			다차원 배열 선언:
		int[][][] cube;
//			배열을 특정 크기로 초기화:
		int[] numbers2 = new int[10];
//			배열에 초기값을 지정:
		int[] numbers3 = { 1, 2, 3, 4, 5 };
		
		int[] numbers = numbers3;
		
//			배열에 객체를 초기값으로 지정:
		String[] names2 = { "John", "Jane", "Jack" };

		
		So.ln("값 찍어보기:" + numbers[2]);
		
	}
}
