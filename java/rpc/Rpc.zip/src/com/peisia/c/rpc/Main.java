package com.peisia.c.rpc;

public class Main {
	public static void main(String[] args) {
		Rpc rpc = new Rpc();
		rpc.run();
	}
}