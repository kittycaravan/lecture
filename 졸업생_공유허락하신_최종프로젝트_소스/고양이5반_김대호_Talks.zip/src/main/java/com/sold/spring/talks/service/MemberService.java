package com.sold.spring.talks.service;

import com.sold.spring.talks.dto.MemberDto;

public interface MemberService {
	public void createMember(MemberDto memberDto);
	public MemberDto login(MemberDto memberDto);

}
