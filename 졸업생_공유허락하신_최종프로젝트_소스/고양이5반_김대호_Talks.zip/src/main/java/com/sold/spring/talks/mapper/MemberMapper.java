
package com.sold.spring.talks.mapper;

import com.sold.spring.talks.dto.MemberDto;

public interface MemberMapper {
	public void createMember(MemberDto memberDto);
	public MemberDto login(MemberDto memberDto);

}
