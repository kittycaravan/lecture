package com.peisia.spring.mi.service.ef.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.mi.mapper.ef.member.EfMemberMapper;
import com.peisia.spring.mi.vo.ef.member.MemberVo;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class EfMemberServiceImpl implements EfMemberService{

	@Setter(onMethod_ = @Autowired)
	private EfMemberMapper mapper;

	@Override
	public void write(MemberVo mvo) {
		mapper.write(mvo);
	}
}