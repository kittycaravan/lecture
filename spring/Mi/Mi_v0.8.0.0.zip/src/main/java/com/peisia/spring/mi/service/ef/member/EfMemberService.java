package com.peisia.spring.mi.service.ef.member;


import com.peisia.spring.mi.vo.ef.member.MemberVo;

public interface EfMemberService {
	public void write(MemberVo mvo);
}
