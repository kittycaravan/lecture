var a,b,r;
window.onload=function(){
	r = document.getElementById("r");
	var xhr = new XMLHttpRequest();
	a = document.getElementById("cat1");
	a.addEventListener("click", function() {
		xhr.open('GET', '/api/catOne'); // HTTP 메서드와 요청 URL 설정		
		xhr.send(); // 요청 보내기		
		xhr.onload = function() {		
			if (xhr.status === 200) { // 응답 상태 확인	
				var j = xhr.responseText;
				var jo = JSON.parse(j)
				r.innerHTML = "이름:"+jo.name+" 나이:"+jo.age;
			} else {	
				console.error(xhr.statusText); // 오류 메시지 출력
			}	
		};		
	});
	b = document.getElementById("cat2");
	b.addEventListener("click", function() {
		xhr.open('GET', '/api/catTwo'); // HTTP 메서드와 요청 URL 설정		
		xhr.send(); // 요청 보내기		
		xhr.onload = function() {		
			if (xhr.status === 200) { // 응답 상태 확인	
				var j = xhr.responseText;
				var jo = JSON.parse(j)
				r.innerHTML = "이름:"+jo.name+" 나이:"+jo.age;
			} else {	
				console.error(xhr.statusText); // 오류 메시지 출력
			}	
		};		
	});
}