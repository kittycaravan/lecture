package com.peisia.spring.mi.vo.ef.shop;

import lombok.Data;

@Data
public class ItemVo {
	private Long no;
	private String name;
	private Long price;
}
