package com.peisia.spring.mi.vo.ef.member;

import lombok.Data;

@Data
public class MemberVo {
	private String id;
	private String name;
	private String pw;
}
