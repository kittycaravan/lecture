$(function () {	// << 이렇게 jquery 3.0 식으로 줄여쓰기. 대신 맨 아래 닫는 괄호들 주의.
	var xhr = new XMLHttpRequest();
	$("#cat1").click(function () {
		$.get("/api/catOne", function (data) {
			var x = JSON.stringify(data);	// 기존 xhr.open.. 식에서 jqeury $.get 문법으로 바꾼 경우 이 코드 처리를 해야 에러가 안남.
			var jo = JSON.parse(x);
			$("#r").text("이름:" + jo.name + " 나이:" + jo.age);
		});
	});
	$("#cat2").click(function () {
		$.ajax({		
			url: "/api/catTwo",	
			method: "GET",	
			dataType: "json",	
			success: function(response) {	
				$("#r").text("이름:" + response.name + " 나이:" + response.age);
			},	
			error: function(xhr, status, error) {	
				console.error(error);
			}	
		});		
	});
});

