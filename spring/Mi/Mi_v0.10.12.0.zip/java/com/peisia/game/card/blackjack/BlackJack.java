package com.peisia.game.card.blackjack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import com.peisia.util.game.Dice;

@Component	//이걸 붙이고 root-context.xml 에..
/*

	이 클래스의 소속 패키지를 아래 base-package 에 작성

	ex.

	<context:component-scan base-package="com.peisia.game.card.blackjack">
	</context:component-scan>

	하면 이 클래스가 스프링이 관리하는 클래스인 빈으로 관리 됨.
	이후 쓰고 싶은 곳에서 (예. 컨트롤러 ) @Autowired 라고 붙이고 쓰면

	ex.
	
	public class GameControllerCardCat {
		@Autowired
		private CardCat game;
		...

	객체 생성 알아서 되서 쓸 수 있게 됨.
*/	
public class BlackJack {
	private static final String MESSAGE_ONEGAME_WIN = "이겼다!!!";
	private static final String MESSAGE_ONEGAME_DRAW = "비겼다..";
	private static final String MESSAGE_ONEGAME_LOSE = "졌다....";
	private static final String MESSAGE_FINAL_WIN = "승리!";
	private static final String MESSAGE_FINAL_LOSE = "패배!";	
	public ArrayList<Card> cards;
	public ArrayList<Card> playerCards;
	public ArrayList<Card> dealerCards;
	public Random rand;
	
	enum GameStatus{
		GAME_PLAYING,
		GAME_OVER
	}
	
	public GameStatus gs;
	
	public static int add(int a,int b) {
		return a+b;
	}
	
	/*
	 * 초기화
	 * : 1.카드를 52장으로 다시 세팅.
	 * : 2.카드를 셔플(섞기)
	 */
	public void startGame(Model m) {
		rand = new Random();
		initGame();
		cardShuffle();
		dealCards(m);
	}	
	public void initGame() {
		gs = GameStatus.GAME_PLAYING;
		cards = new ArrayList<>(Arrays.asList(Card.values()));
		playerCards = new ArrayList<>();
		dealerCards = new ArrayList<>();
	}
	public void cardShuffle() {
		Collections.shuffle(cards);
	}
	public Card drawCard() {
		return cards.remove(rand.nextInt(cards.size())); 
	}
	
	public void dealCards(Model m) {
		dealerCards.add(drawCard());
		System.out.println("남은카드 수:"+cards.size());
		playerCards.add(drawCard());
		System.out.println("남은카드 수:"+cards.size());
		dealerCards.add(drawCard());
		System.out.println("남은카드 수:"+cards.size());
		playerCards.add(drawCard());
		System.out.println("남은카드 수:"+cards.size());
		
		m.addAttribute("dealerCards",dealerCards);
		m.addAttribute("playerCards",playerCards);
		victoryCheck(m,dealerCards,playerCards);
	}
	
	public void victoryCheck(Model m, ArrayList<Card> d, ArrayList<Card> p) {
		int dealerCardSum = getCardSum(d);
		int playerCardSum = getCardSum(p);
		System.out.println("==== 카드 ==== : 딜러 카드 합:"+dealerCardSum);
		System.out.println("==== 카드 ==== : 플레이어 카드 합:"+playerCardSum);
		
		//딜러 규칙 처리
		// 딜러는 16점 이하일 때는 반드시 HIT을 하고, 17점 이상일 때는 STAND를 해야 합니다.
		if(dealerCardSum < 17) {	// 딜러 히트 처리
			while(true) {	//딜러 계속 카드 뽑게 하기
				dealerCards.add(drawCard());
				dealerCardSum = getCardSum(d);
				System.out.println("남은카드 수:"+cards.size());
				
				if(dealerCardSum > 16) {	// 17점 이상일 때는 STAND(카드 그만뽑게 하기)
					break;	//딜러 카드 그만 뽑게 하기
				}
			}
			//여기서 딜러 패배 조건이 발생 할 수 있으므로 조건 판단을 함. 발생 시 처리.
			//딜러가 카드를 추가로 뽑은 결과가 21이 초과되면 무조건 패배 처리
			if(dealerCardSum > 21) {
				//// 카드들 화면으로 넘기고
				m.addAttribute("dealerCardSum",dealerCardSum);
				m.addAttribute("playerCardSum",playerCardSum);
				//// 플레이어 승리 선언
				System.out.println(MESSAGE_ONEGAME_WIN);
				m.addAttribute("message",MESSAGE_ONEGAME_WIN);
				m.addAttribute("gameResultCode",1);
				return;
			}
		}
		//플레이어 추가 카드 처리. 플레이어는 1명으로 설정해서 이 방식으로 함. 
		//플레이어는 딜러 카드 보다 합이 적으면 이기기 위해서 카드 뽑도록 처리. 
		if(dealerCardSum > playerCardSum) {	// 딜러 카드 합이 플레이어 카드 합 보다 높으면
			while(true) {	// 플레이어 카드를 계속 뽑고 결과에 따른 처리하기
				playerCards.add(drawCard());	//플레이어 카드 하나 더 뽑기
				playerCardSum = getCardSum(p);
				System.out.println("남은카드 수:"+cards.size());
				//여기서 플레이어 패배 조건이 발생 할 수 있으므로 조건 판단을 함. 발생 시 처리.
				//플레이어가 카드를 추가로 뽑는 중에 딜러 카드 합보다 크고 21을 초과하지 않으면 플레이어 승리 처리.
				//플레이어가 카드를 추가로 뽑는 중에 21이 초과되면 무조건 패배 처리
				if(playerCardSum > dealerCardSum) {
					//// 카드들 화면으로 넘기고
					m.addAttribute("dealerCardSum",dealerCardSum);
					m.addAttribute("playerCardSum",playerCardSum);
					if(playerCardSum > 21) {
						//// 플레이어 패배 선언
						System.out.println(MESSAGE_ONEGAME_LOSE);
						m.addAttribute("message",MESSAGE_ONEGAME_LOSE);
						m.addAttribute("gameResultCode",-1);
						return;
					} else {
						//// 플레이어 승리 선언
						System.out.println(MESSAGE_ONEGAME_WIN);
						m.addAttribute("message",MESSAGE_ONEGAME_WIN);
						m.addAttribute("gameResultCode",1);
						return;
					}
				}
				//여기서 비김 조건이 발생 할 수 있으므로 조건 판단을 함. 발생 시 처리.
				//업그레이드하면 여기서 유저가 카드를 더 뽑는걸 선택하게 할 수도 있으나
				//일단 이렇게 처리.
				if(playerCardSum == dealerCardSum) {
					//// 비김 선언
					//// 카드들 화면으로 넘기고
					m.addAttribute("dealerCardSum",dealerCardSum);
					m.addAttribute("playerCardSum",playerCardSum);
					System.out.println(MESSAGE_ONEGAME_DRAW);
					m.addAttribute("message",MESSAGE_ONEGAME_DRAW);
					m.addAttribute("gameResultCode",0);
					return;
				}
			}
		}
		m.addAttribute("dealerCardSum",dealerCardSum);
		m.addAttribute("playerCardSum",playerCardSum);
		if(playerCardSum > dealerCardSum) {
			//// 플레이어 승리 선언
			System.out.println(MESSAGE_ONEGAME_WIN);
			m.addAttribute("message",MESSAGE_ONEGAME_WIN);
			m.addAttribute("gameResultCode",1);
		} else if(playerCardSum == dealerCardSum) {
			//// 비김 선언
			m.addAttribute("message",MESSAGE_ONEGAME_DRAW);
			m.addAttribute("gameResultCode",0);			
		} else {
			//// 플레이어 패배 선언
			m.addAttribute("message",MESSAGE_ONEGAME_LOSE);
			m.addAttribute("gameResultCode",-1);
		}
	}
	
	private int getCardSum(ArrayList<Card> cs) {
		int sum=0;
		for(Card c:cs) {
			System.out.println("==== 카드 ==== : 카드 값:"+c.getValue());
			//에이스 예외 처리. ace카드는 일부러 value를 99로 넣어뒀음. 구분을 위해.
			//룰. 에이스는 1 또는 11로 처리 되고 카드 합 상황에 따라 다르게 적용된다.
			if(c.getValue()==99) {	//ace 카드 처리
				//규칙 1: 현재까지 나온 카드의 합이 딱 10인 상태에서 이번 카드가 에이스면 에이스 카드 값을 11로 한다. (그래야 최고점인 21이 딱 채워지고, 이게 ace카드의 장점)
				//규칙 1에 따른 코드
				if(sum==10) {
					return 21;	//리턴하고 끝냄.
				}
				//규칙 2: 현재까지 나온 카드의 합이 딱 10 미만이고 이번 카드가 에이스면 에이스 카드 값을 1로 한다.
				//규칙 2에 따른 코드
				if(sum<10) {
					sum=sum+1;	//에이스를 1로 해서 1만 더함.
				}
				//규칙 3: 현재까지 나온 카드의 합이 딱 10 초과이고 이번 카드가 에이스면 에이스 카드 값을 1로 한다. (안그러면 21 오버로 게임 지니까 ace를 1로 낮추는 개념)
				//규칙 3에 따른 코드
				if(sum>10) {
					sum=sum+1;	//에이스를 1로 해서 1만 더함.
				}
			}else {	//ace 외 카드 처리
				sum=sum+c.getValue();
			}
		}
		return sum;
	}
	
	void gameReady() {
		
	}
	
	void gameRun() {
		
	}
	
	void oneGameRun() {
		
	}
	
	void finalVictoryCheck() {
		
	}

}