package com.peisia.game.card.blackjack;

/* 
 * 숫자 1~13 이랑 무늬도 반영된 트럼프 카드
 * */
public enum Card {
	//대한민국 경찰청이 운영하는 전국 통합 도박신고센터(전화번호: 1336)
	
	//카드 무늬 별 우선순위. 일반룰 기준.
	//스페이드 > 하트 > 다이아몬드 > 클로버 
	
	//SPADE
	//HEART
	//DIAMOND
	//CLUB	클럽. 클로버. Clover 둘 중 하나로 쓰임. 주로 club. 참고로 그 춤추는 클럽 맞음.

	CLUB_TWO(4,2,2,"♣2"),
	DIAMOND_TWO(3,2,2,"💎2"),
	HEART_TWO(2,2,2,"❤2"),
	SPADE_TWO(1,2,2,"♠2"),

	CLUB_THREE(4,3,3,"♣3"),
	DIAMOND_THREE(3,3,3,"💎3"),
	HEART_THREE(2,3,3,"❤3"),
	SPADE_THREE(1,3,3,"♠3"),

	CLUB_FOUR(4,4,4,"♣4"),
	DIAMOND_FOUR(3,4,4,"💎4"),
	HEART_FOUR(2,4,4,"❤4"),
	SPADE_FOUR(1,4,4,"♠4"),

	CLUB_FIVE(4,5,5,"♣5"),
	DIAMOND_FIVE(3,5,5,"💎5"),
	HEART_FIVE(2,5,5,"❤5"),
	SPADE_FIVE(1,5,5,"♠5"),

	CLUB_SIX(4,6,6,"♣6"),
	DIAMOND_SIX(3,6,6,"💎6"),
	HEART_SIX(2,6,6,"❤6"),
	SPADE_SIX(1,6,6,"♠6"),

	CLUB_SEVEN(4,7,7,"♣7"),
	DIAMOND_SEVEN(3,7,7,"💎7"),
	HEART_SEVEN(2,7,7,"❤7"),
	SPADE_SEVEN(1,7,7,"♠7"),

	CLUB_EIGHT(4,8,8,"♣8"),
	DIAMOND_EIGHT(3,8,8,"💎8"),
	HEART_EIGHT(2,8,8,"❤8"),
	SPADE_EIGHT(1,8,8,"♠8"),

	CLUB_NINE(4,9,9,"♣9"),
	DIAMOND_NINE(3,9,9,"💎9"),
	HEART_NINE(2,9,9,"❤9"),
	SPADE_NINE(1,9,9,"♠9"),

	CLUB_TEN(4,10,10,"♣10"),
	DIAMOND_TEN(3,10,10,"💎10"),
	HEART_TEN(2,10,10,"❤10"),
	SPADE_TEN(1,10,10,"♠10"),

	CLUB_JACK(4,11,10,"♣J"),
	DIAMOND_JACK(3,11,10,"💎J"),
	HEART_JACK(2,11,10,"❤J"),
	SPADE_JACK(1,11,10,"♠J"),

	CLUB_QUEEN(4,12,10,"♣Q"),
	DIAMOND_QUEEN(3,12,10,"💎Q"),
	HEART_QUEEN(2,12,10,"❤Q"),
	SPADE_QUEEN(1,12,10,"♠Q"),

	CLUB_KING(4,13,10,"♣K"),
	DIAMOND_KING(3,13,10,"💎K"),
	HEART_KING(2,13,10,"❤K"),
	SPADE_KING(1,13,10,"♠K"),

	CLUB_ACE(4,99,99,"♣A"),
	DIAMOND_ACE(3,99,99,"💎A"),
	HEART_ACE(2,99,99,"❤A"),
	SPADE_ACE(1,99,99,"♠A"),
	;
	
	private int suit;
	private int number;
	private int value;
	private String disp;

	private Card(int suit, int number, int value, String disp) {
		this.suit = suit;
		this.number = number;
		this.value = value;
		this.disp = disp;
	}

	public int getValue() {
		return value;
	}

	public int getSuit() {
		return suit;
	}

	public String getDisp() {
		return disp;
	}

	public int getNumber() {
		return number;
	}
	
	public String getDispAll() {
		return String.format("카드무늬코드: %d, 카드숫자: %d, 카드가치: %d, 카드숫자와 모양: %s" , suit, number, value, disp);
	}
	
	
}