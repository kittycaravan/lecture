package com.peisia.game.card.cardcat;

// Card 열거형 선언
public enum Card {

// 각 상수(TWO~ACE) 정의, 괄호 안의 값은 상수의 정수 값
	TWO(1), // "TWO"라는 이름의 상수, 정수 값은 1
	THREE(2), // "THREE"라는 이름의 상수, 정수 값은 2
	FOUR(3), // "FOUR"라는 이름의 상수, 정수 값은 3
	FIVE(4), // "FIVE"라는 이름의 상수, 정수 값은 4
	SIX(5), // "SIX"라는 이름의 상수, 정수 값은 5
	SEVEN(6), // "SEVEN"라는 이름의 상수, 정수 값은 6
	EIGHT(7), // "EIGHT"라는 이름의 상수, 정수 값은 7
	NINE(8), // "NINE"라는 이름의 상수, 정수 값은 8
	TEN(9), // "TEN"라는 이름의 상수, 정수 값은 9
	JACK(10), // "JACK"라는 이름의 상수, 정수 값은 10
	QUEEN(11), // "QUEEN"이라는 이름의 상수, 정수 값은 11
	KING(12), // "KING"라는 이름의 상수, 정수 값은 12
	ACE(13); // "ACE"라는 이름의 상수, 정수 값은 13

// 각 상수가 가지는 정수 값을 저장하는 변수
	private int value;

// 상수 값을 변수에 할당하는 생성자
	Card(int i) {
		value = i;
	}

// 상수 값이 저장된 변수를 반환하는 메소드
	public int getValue() {
		return value;
	}
}