package com.peisia.spring.mi.controller.game.cardcat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peisia.game.card.cardcat.CardCat;

@RequestMapping("/game/cardcat")
@Controller
public class GameControllerCardCat {
	@Autowired
	private CardCat game;
	
	@GetMapping("/main")
	public void main(){
		game.test();
	}	
	@GetMapping("/run")
	public void run(Model m){
		m = game.run(m);
	}	
}