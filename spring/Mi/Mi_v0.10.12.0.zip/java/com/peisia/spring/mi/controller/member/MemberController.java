package com.peisia.spring.mi.controller.member;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.peisia.spring.mi.service.member.MemberService;
import com.peisia.spring.mi.vo.member.MemberVo;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@SessionAttributes("id")	//세션 객체에 아래 매핑된 함수들 중 Model 객체를 사용하고, Model 에 "id" 라는 키로 어떤 값을 넣게되면
							//이 어노테이션 설정에 의해 세션에도 "id" 키로 하고 아까 Model에서 "id"키에 넣었던 값을 또 넣어줌.
@Log4j
@RequestMapping("/member")
@AllArgsConstructor
@Controller
public class MemberController {
	
	private MemberService service;
	
//	@GetMapping("/login")
//	public void login(){}
	
	
	@PostMapping("/login")
	public String login(MemberVo mvo, Model m){
		MemberVo member = service.login(mvo);
		m.addAttribute("id",member.getId());
		return "redirect:/";
	}
	
	@GetMapping("/join")
	public void join(){}
	
	@PostMapping("/join")
//	public String join(@RequestParam("id") String id){
//	public String join(String id,String name,String pw){	// 이름이 동일하면 생략 가능
	public String join(MemberVo mvo){	// 이름이 동일하면 생략 가능
		log.info("==== ef ==== : 회원가입처리. id:"+mvo.getId());
		log.info("==== ef ==== : 회원가입처리. 이름:"+mvo.getName());
		log.info("==== ef ==== : 회원가입처리. pw:"+mvo.getPw());
		service.write(mvo);
		return "redirect:/";
	}

	@GetMapping("/logout")
	public String logout(HttpSession s, SessionStatus status){
		s.removeAttribute("id");
		status.setComplete();  // Model에 있는 SessionAttributes를 제거
		s.invalidate();
		return "redirect:/";
	}
	
	@GetMapping("/mypage")
	public void mypage(){}
	
}