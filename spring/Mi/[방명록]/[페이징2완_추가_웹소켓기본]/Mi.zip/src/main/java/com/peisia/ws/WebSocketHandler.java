package com.peisia.ws;

import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import lombok.extern.log4j.Log4j;

/**************************************************************** 
 * 3/3. 웹소켓 핸들러 ( 메세지 받게 되는 부분 ) 처리 
 *****************************************************************/
@Log4j
public class WebSocketHandler extends TextWebSocketHandler {

    @Override
    protected void handleTextMessage(WebSocketSession s, TextMessage msg) throws Exception {
        // 클라이언트로부터 메시지를 받았을 때 처리할 내용
        String clientMsg = msg.getPayload();
        log.info("😻받은 메세지: " + clientMsg);
        
        // 클라이언트에게 응답을 보낼 수도 있습니다.
        s.sendMessage(new TextMessage("😻서버가 받은 네 메세지 다시 찍은거: " + clientMsg));
    }
}
