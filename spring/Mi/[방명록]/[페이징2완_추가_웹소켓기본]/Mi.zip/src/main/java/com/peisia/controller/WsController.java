package com.peisia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.log4j.Log4j;


/**************************************************************** 
 * 2/3. 전송 화면 진입용 컨트롤러 (웹 소켓 관련 필수 내용은 없음) 
 *****************************************************************/
@Log4j
@RequestMapping("/ws/*")
//@AllArgsConstructor
@Controller
public class WsController {
	
	@GetMapping("/init")
	public void init() {
		log.info("😻==== 웹소켓 테스트");
	}
	
}
