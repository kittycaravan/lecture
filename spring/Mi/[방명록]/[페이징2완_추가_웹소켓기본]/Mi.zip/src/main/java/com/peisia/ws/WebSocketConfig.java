package com.peisia.ws;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

/**************************************************************** 
 * 0/3.콘픽 Config 설정 
 *****************************************************************/
@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
    	// *주의* "/xxx" 가 웹소켓 경로임.
    	// 웹페이지의 js에
    	// ex. var socket = new WebSocket("ws://localhost:8080/xxx");
    	// 여기에 경로 똑같이 맞춰줘야함.
        registry.addHandler(new WebSocketHandler(), "/xxx")
                .setAllowedOrigins("*");
    }
}
