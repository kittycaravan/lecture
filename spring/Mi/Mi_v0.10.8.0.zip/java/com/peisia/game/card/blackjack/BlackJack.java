package com.peisia.game.card.blackjack;

import org.springframework.stereotype.Component;

import com.peisia.util.game.Dice;

@Component	//이걸 붙이고 root-context.xml 에..
/*

	이 클래스의 소속 패키지를 아래 base-package 에 작성

	ex.

	<context:component-scan base-package="com.peisia.game.card.blackjack">
	</context:component-scan>

	하면 이 클래스가 스프링이 관리하는 클래스인 빈으로 관리 됨.
	이후 쓰고 싶은 곳에서 (예. 컨트롤러 ) @Autowired 라고 붙이고 쓰면

	ex.
	
	public class GameControllerCardCat {
		@Autowired
		private CardCat game;
		...

	객체 생성 알아서 되서 쓸 수 있게 됨.
*/	
public class BlackJack {
	public void test() {
		Card[] cards = Card.values();
		Card cardUser = cards[Dice.between(0, 13*4-1)];
		Card cardCom = cards[Dice.between(0, 13*4-1)];
		System.out.println("나:"+cardUser.getDisp());
		System.out.println("나:"+cardUser.getNumber());
		System.out.println("나:"+cardUser.getSuit());
		System.out.println("나:"+cardUser.getValue());
		System.out.println("컴터:"+cardCom.getDisp());
		System.out.println("컴터:"+cardCom.getNumber());
		System.out.println("컴터:"+cardCom.getSuit());
		System.out.println("컴터:"+cardCom.getValue());
		if(cardUser.getValue() > cardCom.getValue()) {
			System.out.println("이겼다!");
		} else if(cardUser.getValue() == cardCom.getValue()) {
				System.out.println("비겼네..");
		} else {
			System.out.println("졌네....");
		}
		
	}
	
	void gameReady() {
		
	}
	
	void gameRun() {
		
	}
	
	void oneGameRun() {
		
	}
	
	void victoryCheck() {
		
	}
	
	void finalVictoryCheck() {
		
	}

}