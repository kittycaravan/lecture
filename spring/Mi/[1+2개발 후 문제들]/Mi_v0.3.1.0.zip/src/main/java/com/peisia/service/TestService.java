package com.peisia.service;

public interface TestService {
	public String getOne();
	public String getTwo();
	
	public void updateVisitantCount();	/* 문제 1 */
}
