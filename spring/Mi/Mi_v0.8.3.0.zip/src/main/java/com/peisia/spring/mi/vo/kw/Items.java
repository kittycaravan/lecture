
package com.peisia.spring.mi.vo.kw;

import java.util.List;

public class Items {

    public List<Item> item;

}
