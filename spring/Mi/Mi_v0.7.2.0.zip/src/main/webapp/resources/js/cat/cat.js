//window.onload=function(){ //를
$(function() {	// << 이렇게 jquery 3.0 식으로 줄여쓰기. 대신 맨 아래 닫는 괄호들 주의.
//	r = document.getElementById("r");
	var xhr = new XMLHttpRequest(); 
	//jqeury : 선택한 요소에 이벤트 핸들러 추가		$(selector).on(event, function);
	//a = document.getElementById("cat1");
	//a.addEventListener("click", function() {
	//$("#cat1").on("click", function() {	// 이 jquery 문은 다시 아래껄로 더 줄일 수 있음.
	$("#cat1").click(function() {
		//아래 두번째 버튼 처리한거랑 비교 해보시오.. 방식을 다르게 처리 했음.
	    $.get("/api/catOne", function(data) {
	    	var x = JSON.stringify(data);	// 기존 xhr.open.. 식에서 jqeury $.get 문법으로 바꾼 경우 이 코드 처리를 해야 에러가 안남.
	    	var jo = JSON.parse(x);
	    	$("#r").text("이름:" + jo.name + " 나이:" + jo.age);
    	});
	});
	//b = document.getElementById("cat2");
	//b.addEventListener("click", function() {
	//$("#cat2").on("click", function() {	// 이 jquery 문은 다시 아래껄로 더 줄일 수 있음.
	$("#cat2").click(function() {
		xhr.open('GET', '/api/catTwo'); // HTTP 메서드와 요청 URL 설정		
		xhr.send(); // 요청 보내기		
		xhr.onload = function() {		
			if (xhr.status === 200) { // 응답 상태 확인	
				var j = xhr.responseText;
				var jo = JSON.parse(j)
				$("#r").text("이름:"+jo.name+" 나이:"+jo.age);	//jQuery
			} else {	
				console.error(xhr.statusText); // 오류 메시지 출력
			}	
		};		
	});
//	} 대신
});	// 이렇게 마무리 해야되는거 주의.