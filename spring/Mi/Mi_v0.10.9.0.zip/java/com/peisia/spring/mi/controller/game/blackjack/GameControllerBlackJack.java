package com.peisia.spring.mi.controller.game.blackjack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peisia.game.card.blackjack.BlackJack;

@RequestMapping("/game/blackjack")
@Controller
public class GameControllerBlackJack {
	@Autowired
	private BlackJack game;
	
	@GetMapping("/main")
	public void main(Model m){
		game.run(m);
	}	
	@GetMapping("/run")
	public void run(Model m){
//		m = game.run(m);
	}	
}