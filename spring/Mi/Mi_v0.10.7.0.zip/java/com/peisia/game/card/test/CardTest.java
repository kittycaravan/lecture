package com.peisia.game.card.test;

import com.peisia.util.game.Dice;

public class CardTest {
	public void gameReady() {
		
	}
	
	public void gameRun() {
		
	}
	
	public void oneGameRun() {
		Card[] cards = Card.values();
		Card cardUser = cards[Dice.between(0, 12)];
		Card cardCom = cards[Dice.between(0, 12)];
		System.out.println("나:"+cardUser);
		System.out.println("컴터:"+cardCom);
		if(cardUser.ordinal() > cardCom.ordinal()) {
			System.out.println("이겼다!");
		} else if(cardUser.ordinal() == cardCom.ordinal()) {	//enum 숫
			System.out.println("비겼네..");
		} else {
			System.out.println("졌네....");
		}
	}
	
	public void victoryCheck() {
		
	}
	
	public void finalVictoryCheck() {
		
	}

}