package com.peisia.game.card.blackjack;

import com.peisia.util.game.Dice;

public class BlackJack {
	public static void test() {
		Card[] cards = Card.values();
		Card cardUser = cards[Dice.between(0, 12)];
		Card cardCom = cards[Dice.between(0, 12)];
		System.out.println("나:"+cardUser);
		System.out.println("컴터:"+cardCom);
		if(cardUser.ordinal() > cardCom.ordinal()) {
			System.out.println("이겼다!");
		} else {
			System.out.println("지거나 비겼음");
		}
		
	}
	
	void gameReady() {
		
	}
	
	void gameRun() {
		
	}
	
	void oneGameRun() {
		
	}
	
	void victoryCheck() {
		
	}
	
	void finalVictoryCheck() {
		
	}

}