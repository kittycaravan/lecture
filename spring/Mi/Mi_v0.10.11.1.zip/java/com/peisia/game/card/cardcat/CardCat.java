package com.peisia.game.card.cardcat;

import java.util.HashMap;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import com.peisia.util.game.Dice;

@Component	//이걸 붙이고 root-context.xml 에..
/*

	이 클래스의 소속 패키지를 아래 base-package 에 작성

	ex.

	<context:component-scan base-package="com.peisia.game.card.cardcat">
	</context:component-scan>

	하면 이 클래스가 스프링이 관리하는 클래스인 빈으로 관리 됨.
	이후 쓰고 싶은 곳에서 (예. 컨트롤러 ) @Autowired 라고 붙이고 쓰면

	ex.
	
	public class GameControllerCardCat {
		@Autowired
		private CardCat game;
		...

	객체 생성 알아서 되서 쓸 수 있게 됨.
*/	
public class CardCat {
	private static final int USER_START_GOLD = 10;
	private static final int COM_START_GOLD = 10;
	private static final String MESSAGE_ONEGAME_WIN = "이겼다!!!";
	private static final String MESSAGE_ONEGAME_DRAW = "비겼다..";
	private static final String MESSAGE_ONEGAME_LOSE = "졌다....";
	private static final String MESSAGE_FINAL_WIN = "승리!";
	private static final String MESSAGE_FINAL_LOSE = "패배!";
	private int gameState = 0;
	private int userGold = USER_START_GOLD;
	private int comGold = COM_START_GOLD;
	private String lastResult;
	private HashMap<String,Object> gameData = new HashMap<>();
	
	
	public HashMap<String,Object> getGameData() {
		gameData.put("userGold",userGold);
		gameData.put("comGold",comGold);
		gameData.put("gameState",gameState);
		gameData.put("lastResult",lastResult);
		return gameData;
	}
	
	public Model run(Model m) {
		Card[] cards = Card.values();
		Card cardUser = cards[Dice.between(0, 12)];
		Card cardCom = cards[Dice.between(0, 12)];
		System.out.println("나:"+cardUser);
		System.out.println("컴터:"+cardCom);
		m.addAttribute("cardUser",cardUser);
		m.addAttribute("cardCom",cardCom);
		return victoryCheck(m,cardUser,cardCom);
	}
	
	public Model victoryCheck(Model m, Card cardUser, Card cardCom) {
		if(cardUser.ordinal() > cardCom.ordinal()) {
			System.out.println(MESSAGE_ONEGAME_WIN);
			m.addAttribute("message",MESSAGE_ONEGAME_WIN);
			m.addAttribute("gameResultCode",1);
		} else if(cardUser.ordinal() == cardCom.ordinal()) {	//enum 숫
			m.addAttribute("message",MESSAGE_ONEGAME_DRAW);
			m.addAttribute("gameResultCode",0);			
		} else {
			m.addAttribute("message",MESSAGE_ONEGAME_LOSE);
			m.addAttribute("gameResultCode",-1);
		}
		return m;
	}
	
	public boolean finalVictoryCheck() {
		if(comGold > 0) {
			return false; 
		}else {
			return true;
		}
	}
	public boolean finalLoseCheck() {
		if(userGold > 0) {
			return false; 
		}else {
			return true;
		}
	}
	
	public void test() {
		System.out.println("==== 호출 잘됨");
	}

}