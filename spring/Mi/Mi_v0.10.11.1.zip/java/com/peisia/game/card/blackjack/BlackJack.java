package com.peisia.game.card.blackjack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import com.peisia.util.game.Dice;

@Component	//이걸 붙이고 root-context.xml 에..
/*

	이 클래스의 소속 패키지를 아래 base-package 에 작성

	ex.

	<context:component-scan base-package="com.peisia.game.card.blackjack">
	</context:component-scan>

	하면 이 클래스가 스프링이 관리하는 클래스인 빈으로 관리 됨.
	이후 쓰고 싶은 곳에서 (예. 컨트롤러 ) @Autowired 라고 붙이고 쓰면

	ex.
	
	public class GameControllerCardCat {
		@Autowired
		private CardCat game;
		...

	객체 생성 알아서 되서 쓸 수 있게 됨.
*/	
public class BlackJack {
	private static final String MESSAGE_ONEGAME_WIN = "이겼다!!!";
	private static final String MESSAGE_ONEGAME_DRAW = "비겼다..";
	private static final String MESSAGE_ONEGAME_LOSE = "졌다....";
	private static final String MESSAGE_FINAL_WIN = "승리!";
	private static final String MESSAGE_FINAL_LOSE = "패배!";	
	public ArrayList<Card> cards;
	public ArrayList<Card> playerCards;
	public ArrayList<Card> dealerCards;
	public Random rand;
	
	enum GameStatus{
		GAME_PLAYING,
		GAME_OVER
	}
	
	public GameStatus gs;
	
	public static int add(int a,int b) {
		return a+b;
	}
	
	/*
	 * 초기화
	 * : 1.카드를 52장으로 다시 세팅.
	 * : 2.카드를 셔플(섞기)
	 */
	public void startGame(Model m) {
		rand = new Random();
		initGame();
		cardShuffle();
		dealCards(m);
	}	
	public void initGame() {
		gs = GameStatus.GAME_PLAYING;
		cards = new ArrayList<>(Arrays.asList(Card.values()));
		playerCards = new ArrayList<>();
		dealerCards = new ArrayList<>();
	}
	public void cardShuffle() {
		Collections.shuffle(cards);
	}
	public Card drawCard() {
		return cards.remove(rand.nextInt(cards.size())); 
	}
	
	public void dealCards(Model m) {
		dealerCards.add(drawCard());
		System.out.println("남은카드 수:"+cards.size());
		playerCards.add(drawCard());
		System.out.println("남은카드 수:"+cards.size());
		dealerCards.add(drawCard());
		System.out.println("남은카드 수:"+cards.size());
		playerCards.add(drawCard());
		System.out.println("남은카드 수:"+cards.size());
		
		m.addAttribute("dealerCards",dealerCards);
		m.addAttribute("playerCards",playerCards);
		victoryCheck(m,dealerCards,playerCards);
	}
	
	public void victoryCheck(Model m, ArrayList<Card> d, ArrayList<Card> p) {
		//todo 룰 처리. 임시.
		//두 카드의 밸류 합
		
		if(p.get(0).getValue()+p.get(1).getValue() > d.get(0).getValue()+d.get(0).getValue()) {
			System.out.println(MESSAGE_ONEGAME_WIN);
			m.addAttribute("message",MESSAGE_ONEGAME_WIN);
			m.addAttribute("gameResultCode",1);
		} else if(p.get(0).getValue()+p.get(1).getValue() == d.get(0).getValue()+d.get(0).getValue()) {
			m.addAttribute("message",MESSAGE_ONEGAME_DRAW);
			m.addAttribute("gameResultCode",0);			
		} else {
			m.addAttribute("message",MESSAGE_ONEGAME_LOSE);
			m.addAttribute("gameResultCode",-1);
		}
	}
	
	void gameReady() {
		
	}
	
	void gameRun() {
		
	}
	
	void oneGameRun() {
		
	}
	
	void finalVictoryCheck() {
		
	}

}