package com.peisia.util.game;

public class Dice {
	/* 6면체 주사위 값 구하기 */
	public static int roll() {
		return (int)(Math.random()*6+1);
	}
	/* n면체 주사위 값 구하기 */
	public static int roll(int polyhedronCount) {	// polyhedronCount = 면체 수
		return (int)(Math.random()*polyhedronCount+1);
	}
	/* min~max 사이의 랜덤 값 구하기 */
	public static int between(int min, int max) {
		int x = max - min + 1;
		int r = (int)(Math.random()*x) + min;
		return r;
	}
	
	/* min~max 사이의 랜덤 값 구하기. (추가 조건 per 만큼 배수인 값만) */
	//per ex. 5씩
	//90 ~ 100
	//90 95 100
	//100 - 90
	//10 / 5 = 2  < + 1하고
	//이값 관리 3	
	//0 1 2 나오게 하고
	//여기에 per 곱하고
	//최소랑 더하기
	public static int betweenAndPer(int min, int max,int per) {
		int t = (max - min) / per + 1;
//		int cha = max - min + 1;
		int r = (int)(Math.random()*t) * per + min;
		return r;
	}
}