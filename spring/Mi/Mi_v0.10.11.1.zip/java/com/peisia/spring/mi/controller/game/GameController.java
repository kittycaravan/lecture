package com.peisia.spring.mi.controller.game;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peisia.game.card.blackjack.BlackJack;
import com.peisia.game.card.cardcat.CardCat;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/game")
@AllArgsConstructor
@Controller
public class GameController {
	@GetMapping("/main")
	public void main(){}
	
	@GetMapping("/poker")
	public void poker(){
		
	}
	
	
}
