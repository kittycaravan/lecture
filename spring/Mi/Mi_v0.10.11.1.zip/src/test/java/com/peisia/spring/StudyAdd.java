package com.peisia.spring;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.peisia.game.card.blackjack.BlackJack;

public class StudyAdd {
	
//	assertTrue(boolean condition) : 주어진 조건(condition)이 참인지 검증합니다.
//	assertFalse(boolean condition) : 주어진 조건(condition)이 거짓인지 검증합니다.
//	assertNull(Object object) : 주어진 객체(object)가 null인지 검증합니다.
//	assertNotNull(Object object) : 주어진 객체(object)가 null이 아닌지 검증합니다.
//	assertSame(Object expected, Object actual) : 주어진 두 객체(expected, actual)가 같은 객체인지 검증합니다.
//	assertNotSame(Object expected, Object actual) : 주어진 두 객체(expected, actual)가 다른 객체인지 검증합니다.
//	assertEquals(expected, actual) : 주어진 두 값(expected, actual)이 같은지 검증합니다. 이때 값의 타입은 상관없습니다.
//	assertEquals(expected, actual, delta) : 주어진 두 값(expected, actual)의 차이가 delta 이하인지 검증합니다. 이때 값의 타입은 double 또는 float여야 합니다.
	
    @Test
    public void testAdd() {
        int result = BlackJack.add(2, 3);
        assertEquals(5, result);
    }
    @Test
    public void testAdd2() {
    	int result = BlackJack.add(2, 2);
    	assertEquals(5, result);
    }
}
