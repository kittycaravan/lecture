package com.peisia.spring.mi.controller.file;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@SessionAttributes("id")
public class FileController {
	//// /resources/ 경로로 업로드 시	////
//	private static final String UPLOAD_DIR = "D:\\00_sungmo\\03_sts3_workspace\\Mi\\src\\main\\webapp\\resources\\upload\\";
//	private static final String UPLOAD_DIR = "src/main/webapp/resources/upload/";
//	private static final String UPLOAD_DIR = "src\\main\\webapp\\resources\\upload\\";
//	private static final String UPLOAD_DIR = "/resources/upload/";
//	private static final String UPLOAD_DIR = "\\resources\\upload\\"; << 다 안됨.
//	private static final String UPLOAD_DIR = "resources/upload/";
	private static final String UPLOAD_BASE_DIR = "/resources/upload/";
	private static final String FILE_NAME_PROFILE_JPG = "profile.jpg";
	
	@Autowired
	private ServletContext servletContext;
	
	@GetMapping("/upload")
	public void upload(){}
	
	@PostMapping("/upload")
	public String upload(@RequestParam("file") MultipartFile file, @ModelAttribute("id") String id) {
		log.info("=========== id:"+id);
		String uploadPath = servletContext.getRealPath(UPLOAD_BASE_DIR+id+"/");
	    // 파일 업로드 처리 로직
//	    String fileName = file.getOriginalFilename();
//	    Path filePath = Paths.get(uploadPath + fileName);
//        try {
//            Files.write(filePath, file.getBytes());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
		
		Path uploadDir = Paths.get(uploadPath);

		if (!Files.exists(uploadDir)) {
		    try {
		        Files.createDirectories(uploadDir);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		}

//		String fileName = file.getOriginalFilename();
		Path filePath = uploadDir.resolve(FILE_NAME_PROFILE_JPG);
		// 파일 업로드 처리 로직
		try {
		    Files.write(filePath, file.getBytes());
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
//	    return "upload_success";	// 업로드 후 돌아갈 화면. upload_success.jsp
	    return "/member/mypage";	// 업로드 후 돌아갈 화면. upload_success.jsp
	}
}