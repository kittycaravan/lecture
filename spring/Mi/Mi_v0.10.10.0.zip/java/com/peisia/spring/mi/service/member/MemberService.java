package com.peisia.spring.mi.service.member;


import com.peisia.spring.mi.vo.member.MemberVo;

public interface MemberService {
	public void write(MemberVo mvo);
	public MemberVo login(MemberVo mvo);
}
