package com.peisia.spring.mi.mapper.member;

import com.peisia.spring.mi.vo.member.MemberVo;

public interface MemberMapper {
	public void write(MemberVo mvo);
	public MemberVo login(MemberVo mvo);
}

