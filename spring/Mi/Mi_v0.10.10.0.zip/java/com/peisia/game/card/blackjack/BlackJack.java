package com.peisia.game.card.blackjack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import com.peisia.util.game.Dice;

@Component	//이걸 붙이고 root-context.xml 에..
/*

	이 클래스의 소속 패키지를 아래 base-package 에 작성

	ex.

	<context:component-scan base-package="com.peisia.game.card.blackjack">
	</context:component-scan>

	하면 이 클래스가 스프링이 관리하는 클래스인 빈으로 관리 됨.
	이후 쓰고 싶은 곳에서 (예. 컨트롤러 ) @Autowired 라고 붙이고 쓰면

	ex.
	
	public class GameControllerCardCat {
		@Autowired
		private CardCat game;
		...

	객체 생성 알아서 되서 쓸 수 있게 됨.
*/	
public class BlackJack {
	private static final String MESSAGE_ONEGAME_WIN = "이겼다!!!";
	private static final String MESSAGE_ONEGAME_DRAW = "비겼다..";
	private static final String MESSAGE_ONEGAME_LOSE = "졌다....";
	private static final String MESSAGE_FINAL_WIN = "승리!";
	private static final String MESSAGE_FINAL_LOSE = "패배!";	
	public ArrayList<Card> cards;
	
	public static int add(int a,int b) {
		return a+b;
	}
	
	/*
	 * 초기화
	 * : 1.카드를 52장으로 다시 세팅.
	 * : 2.카드를 셔플(섞기)
	 */
	public void startGame(Model m) {
		initGame();
		cardShuffle();
		dealCards(m);
	}	
	public void initGame() {
		cards = new ArrayList<>(Arrays.asList(Card.values()));
	}
	public void cardShuffle() {
		ArrayList<Card> cards = new ArrayList<>(Arrays.asList(Card.values()));
		Collections.shuffle(cards);
	}
	public Card drawCard() {
		Random rand = new Random();
		return cards.remove(rand.nextInt(cards.size())); 
	}
	
	public void dealCards(Model m) {
//		Card[] cards = Card.values();
//		Card cardUser = cards[Dice.between(0, 13*4-1)];
//		Card cardCom = cards[Dice.between(0, 13*4-1)];
		Card cardUser = drawCard();
		Card cardCom = drawCard();
		System.out.println("나:"+cardUser.getDispAll());
		System.out.println("컴터:"+cardCom.getDispAll());
		m.addAttribute("cardUser",cardUser);
		m.addAttribute("cardCom",cardCom);
		victoryCheck(m,cardUser,cardCom);
	}
	
	public void victoryCheck(Model m, Card cardUser, Card cardCom) {
		if(cardUser.getValue() > cardCom.getValue()) {
			System.out.println(MESSAGE_ONEGAME_WIN);
			m.addAttribute("message",MESSAGE_ONEGAME_WIN);
			m.addAttribute("gameResultCode",1);
		} else if(cardUser.getValue() == cardCom.getValue()) {
			m.addAttribute("message",MESSAGE_ONEGAME_DRAW);
			m.addAttribute("gameResultCode",0);			
		} else {
			m.addAttribute("message",MESSAGE_ONEGAME_LOSE);
			m.addAttribute("gameResultCode",-1);
		}
	}
	
	void gameReady() {
		
	}
	
	void gameRun() {
		
	}
	
	void oneGameRun() {
		
	}
	
	void finalVictoryCheck() {
		
	}

}