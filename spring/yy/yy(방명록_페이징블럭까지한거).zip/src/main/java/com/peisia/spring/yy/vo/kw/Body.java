package com.peisia.spring.yy.vo.kw; 
public class Body{
    public String dataType;
    public Items items;
    public int pageNo;
    public int numOfRows;
    public int totalCount;
}
