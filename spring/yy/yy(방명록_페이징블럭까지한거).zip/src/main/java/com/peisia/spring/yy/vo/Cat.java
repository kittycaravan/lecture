package com.peisia.spring.yy.vo;

import lombok.Data;

@Data
public class Cat {
	private String name;
	private Integer age;
}