package com.peisia.spring.yy.vo.kw; 
import java.util.ArrayList; 
public class Items{
    public ArrayList<Item> item;
}
