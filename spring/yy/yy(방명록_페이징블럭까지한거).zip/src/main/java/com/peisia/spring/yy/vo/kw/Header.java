package com.peisia.spring.yy.vo.kw; 
public class Header{
    public String resultCode;
    public String resultMsg;
}
