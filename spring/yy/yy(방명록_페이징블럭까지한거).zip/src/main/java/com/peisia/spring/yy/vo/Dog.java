package com.peisia.spring.yy.vo;

public class Dog {
	public String name;
	public int age;
}
