package com.peisia.spring.yy.vo;

import lombok.Data;

@Data
public class MemberVO {
	private String id;
	private String pw;
}
