package com.peisia.spring.yy.board;

public class ConfigBoard {
	static public int AMOUNT_PER_PAGE = 3;
	static public int PAGE_PER_BLOCK = 3;
}
