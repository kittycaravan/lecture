package com.peisia.spring.yy.vo.kw; 
public class Root{
    public Response response;
}
