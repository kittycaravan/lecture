package com.peisia.spring.yy.vo.kw;

public class KWeatherVo {
	public Response response;
}
