package com.peisia.spring.yy.vo.kw; 
public class Response{
    public Header header;
    public Body body;
}
