
// confirm ( "헬로 월드" );

// alert("야옹");

